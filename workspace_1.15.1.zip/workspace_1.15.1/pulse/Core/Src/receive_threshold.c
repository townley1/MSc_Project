/*
 * receive_threshold.c
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#define BUFF_LENGTH 32768
#define MAX_MESSAGE_LENGTH 96 +3 // sof ends with 1, eof starts with 0// then eof // goes over buff_length if 512
#define WINDOW_LENGTH_bits  247.594 // exactly 151.04 us // depending on how getting SOF these values may need to change
#define WINDOW_LENGTH_bits_DIV 124//123.8
ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;

///////////////////////////////////////////////////////
/////////          CIRCULAR DMA
//////////////////////////////////////////////////////

void receive_threshold(uint8_t *message, int threshold)
{
	uint16_t adc_buff[BUFF_LENGTH];

	//define test variables
	int message_true[] = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,1,0,1,1,0,3};
	char msg[20];
	message[0] = 1;

	//define receiver variables
	int message_location =1, window_temp = 0, iterations = 100,c_1, c_0, k;
	float window_location = 0.0;

	//define EOF variables
	int  threshold_v = 3, received = 0;

	//wait for SOF
	while (__HAL_TIM_GET_COUNTER(&htim7) < 10043) //10043
    {

    }
    HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7,0);

    // start ADC
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buff,BUFF_LENGTH); // this command takes 43.3 us

    while (message_location <105 && received ==0)
    {

    	// reset
    	HAL_TIM_Base_Start(&htim7);
    	c_1=0;c_0=0;
    	window_temp = window_location;
		uint16_t *buff_P = &adc_buff[window_temp];
		if(message_location == 60)
		{
			threshold = threshold *0.999;
		}
		for (k = 0; k < iterations; k++)
		{
			if (buff_P[k] > threshold)
			{
				c_0 +=1;
			}
		}
		for (k = WINDOW_LENGTH_bits; k > ( WINDOW_LENGTH_bits - iterations); k--)
		{
			if (buff_P[k] > threshold)
			{
				c_1 +=1;
			}
		}


		if(c_1 < threshold_v && c_0 < threshold_v && message_location > 24 && message[message_location-1] == 0)
			{
				message[message_location] = 3;
				received = 1;
			}
			else
			{
				if(c_1 > c_0 )
				{
					message[message_location] = 0;
				}
				else
				{
					// signal is a 0
					message[message_location] = 1;
				}
			}

		// IN WHILE

		// update location variables
        message_location +=1;window_location += WINDOW_LENGTH_bits;
        //make sure we dont go too quickly
//        while(__HAL_TIM_GET_COUNTER(&htim7) < 15000) // 12688 if being exact // 3750 for fast data rate
//        {
//
//        }
        HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7,0);

    }

    // OUT WHILE


    // stop ADC
    HAL_ADC_Stop_DMA(&hadc1);

    //DISPLAY TO USER

 // display errors
    int errors =0;
    for(int i=0; i < 98; i++)
	{
    		if(message[i] != message_true[i])
    		{
    			errors+=1;
    		}
	}
    //HAL_Delay(20000);
    sprintf(msg,"%d,  ", errors); // to see end point
	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);


	// display data
    if (errors >1000 && errors <200 )
    {
        // display ADC data

        for(int i=0; i < 100; i++){ // to flush out
                sprintf(msg,"%hu, B ",1);
                HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
            }
        for(int i=0; i < window_location+800; i++){
            sprintf(msg,"%hu, ", adc_buff[i]);
            HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
        }
        sprintf(msg,"////////%d////////// ",  errors); // to see end point
        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);

        HAL_Delay(30000);

    }

//     // check CRC and display UID
	int error1 = check_crc(message);
	disp_uid(message, error1, errors);




}

