/*
 * determine_levels.c
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_adc1;

///////////////////////////////////////////////////////
/////////          CIRCULAR DMA
//////////////////////////////////////////////////////


int findAvg(void)
{
	//define variables for filtering
//	    float a[4] = {1,-2.6862, 2.4197, -0.7302};
	    float a[6] = {1.0000,   -4.4918 ,   8.0941 ,  -7.3121 ,   3.3110,   -0.6011};
		int past[5] = {0,0,0,0,0};

    uint64_t cum_sum = 0;
    int count;
    HAL_TIM_Base_Start(&htim7);
	uint16_t sof_buff[256]; // use same adc just different buffer
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)sof_buff,256); // this command takes 43.3 us
    int  k = 0;
    // GET UNMODULATED AVERAGE
    while (__HAL_TIM_GET_COUNTER(&htim7) < 44940) //54970// 45848, 60270)
	{
//    	count = sof_buff[256 - ((&hdma_adc1)->Instance->NDTR) - 1] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
//    					past[2] = past[1];
//    					past[1] = past[0];
//    					past[0] = count;

		count =sof_buff[256 - ((&hdma_adc1)->Instance->NDTR) - 1] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3] - past[3]*a[4] - past[4]*a[5];
						past[4] = past[3];
						past[3] = past[2];
						past[2] = past[1];
						past[1] = past[0];
						past[0] = count;
    	if(k < 100)
    	{
			cum_sum += count;
			k = k+1;
    	}
    }

    int avg_low = cum_sum/k;

    HAL_ADC_Stop_DMA(&hadc1);

//	char msg[15];
//	sprintf(msg,"LOW: %d,  ", avg_low); // to see end point
//	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
//	sprintf(msg,"\n\r  "); // to see end point
//		HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
//		HAL_Delay(200);

    return avg_low;


}
