/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc2;

TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim11;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM11_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM7_Init(void);
static void MX_ADC2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// libraries
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

#include "receiving_functions.h"

//define values for CRC
#define POLYNOMIAL 0x8408 // x^16 + x^12 + x^5 + 1
#define PRESET_VALUE 0xFFFF
#define NUMBER_OF_BYTES 3

// define values for TRANSMITTER
#define T_PAUSE 793
#define START_PAUSE_00 793
#define START_PAUSE_01 2379
#define START_PAUSE_10 3965
#define START_PAUSE_11 5550
#define START_PAUSE_EOF 1586

// define headers for TRANSMITTER
void transmit_bits(int bit1, int bit2);
void EOF1(void);
void SOF(void);
void transmit_message(int *array, int size_arr);
int calc_crc(int *, int); // outputs MSB first but we always want to transmit LSB first
void decToBinary(int, int *) ;
void generate_binary_message(int message[], int *message_b);



////////////////////////////////////////////////////////////// MAIN /////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM11_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM7_Init();
  MX_ADC2_Init();
  /* USER CODE BEGIN 2 */

  /////////////////////////////////////////////// SETTING UP TRANSMITTER ///////////////////////////////////////////////
  int length_message = (NUMBER_OF_BYTES+2)*8;
  int message[NUMBER_OF_BYTES + 2] = {0x24, 0x01, 0x00, 0x00,0x00};
  int message_b[length_message] ;
  generate_binary_message(message, message_b);
  char msg[15];

  /////////////////////////////////////////////// SETTING UP RECEIVER ///////////////////////////////////////////////
	int avg_p=0, threshold=0;

  uint8_t message_receiver[99];
	int message_true[] = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,1,0,1,1,0,3};
	sprintf(msg,"\n\r"); // to see end point
			HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	int length1 = 8192;
	uint16_t buff1[length1], buff2[length1];
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  int correct = 0;
/////////////////////////////////////////////// WHILE TRANSMITTER ///////////////////////////////////////////////
	for(int k=0; k<50; k++){
		HAL_TIM_Base_Stop(&htim7);
			__HAL_TIM_SET_COUNTER(&htim7,0);
	SOF(); // takes 3 us to stop and reset clock -> come back here -> start clock -> reset pin
	transmit_message(message_b, length_message);
	EOF1();


/////////////////////////////////////////////// WHILE RECEIVER ///////////////////////////////////////////////
	//HAL_TIM_Base_Start(&htim7); // start timer
/*
	while (__HAL_TIM_GET_COUNTER(&htim7) < 62100) //10043
	    {

	    }
	HAL_TIM_Base_Stop(&htim7);
		__HAL_TIM_SET_COUNTER(&htim7,0);
	    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buff,BUFF_LENGTH); // this command takes 43.3 us
	HAL_Delay(100);
	HAL_ADC_Stop_DMA(&hadc1);
    for(int i=0; i < 100; i++){ // to flush out
            sprintf(msg,"%hu, B ",1);
            HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
        }
    for(int i=0; i < 20000; i++){
        sprintf(msg,"%hu, ", adc_buff[i]);
        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
    }
    sprintf(msg,"//////////////////////////// "); // to see end point
    HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);

    HAL_Delay(25000);*/

	HAL_TIM_Base_Start(&htim7); // start timer

	//toa();
	//// DETECTOR ////

	//threshold = determine_levels() ;
	//receive_threshold(message_receiver,threshold);//, threshold);
	//threshold = determine_levels_df() ;
	//receive_threshold_df(message_receiver,threshold);

	//avg_p = find_SOF();
    //receive(message_receiver, avg_p);
	//receive_filtered(message_receiver, avg_p);

	//// NO DETECTOR ////
	//threshold = findAvg();
	receive_difference(message_receiver);
	//receive_derivative(message_receiver, threshold);

	//receive_correlation_filtered(message_receiver);
/*
	while (__HAL_TIM_GET_COUNTER(&htim7) < 32100) //62100  10043 15993
		{

		}
	 HAL_TIM_Base_Stop(&htim7);
	       __HAL_TIM_SET_COUNTER(&htim7,0);

	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)buff1,length1); // this command takes 43.3 us
	HAL_ADC_Start_DMA(&hadc2, (uint32_t*)buff2,length1); // this command takes 43.3 us
	HAL_Delay(100);
	HAL_ADC_Stop_DMA(&hadc1);
	HAL_ADC_Stop_DMA(&hadc2);

    for(int i=0; i < 100; i++){ // to flush out
            sprintf(msg,"B, ");
            HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
        }
    for(int i=4; i < length1; i++){
		sprintf(msg,"%hu, ", buff1[i]);
        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
    }
    sprintf(msg,"\n\r"); // to see end point
        			HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
    for(int i=4; i < length1; i++){

		sprintf(msg,"%hu, ", buff2[i]);
        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
    }
    sprintf(msg,"\n\r"); // to see end point
    			HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
    			sprintf(msg,"\n\r"); // to see end point
    			    			HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
    HAL_Delay(30000);
*/


	int errors =0;
	for(int i=1; i < 97; i++)
	{
			if(message_receiver[i] != message_true[i])
			{
				errors+=1;
			}

	}
	if (errors<0)
	{
		correct +=1;
	}
	correct+=errors;

	// delay then retransmit
	HAL_Delay(100);
	}
	sprintf(msg,"%d,  ", correct); // to see end point
		HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
		HAL_Delay(1000);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_10B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc2.Init.Resolution = ADC_RESOLUTION_10B;
  hadc2.Init.ScanConvMode = DISABLE;
  hadc2.Init.ContinuousConvMode = ENABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DMAContinuousRequests = ENABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 1-1;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 65535;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief TIM11 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM11_Init(void)
{

  /* USER CODE BEGIN TIM11_Init 0 */

  /* USER CODE END TIM11_Init 0 */

  /* USER CODE BEGIN TIM11_Init 1 */

  /* USER CODE END TIM11_Init 1 */
  htim11.Instance = TIM11;
  htim11.Init.Prescaler = 2-1;
  htim11.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim11.Init.Period = 6343;
  htim11.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim11.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim11) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM11_Init 2 */

  /* USER CODE END TIM11_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
  /* DMA2_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6|GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB6 PB8 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////// MY FUNCTIONS ///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////// TRANSMITTER ///////////////////////////////////////////////

void transmit_message(int *array, int size_arr)
{
	int count;
	for(count = 0; count < size_arr; count+=2)
	{
		transmit_bits(array[count], array[count+1]); // transmit 2 bits
	}
}

void transmit_bits(int bit2, int bit1) // takes about 130 cycles to leave then come back into function
{
	//clock is at 84MHz
	if (bit1 == 0 && bit2 == 0)
	{
		// delay is 128/fc

		while (((&htim11)->Instance->CNT) < START_PAUSE_00)
		{

		}
		GPIOB->BSRR = (uint32_t)GPIO_PIN_8 << 16U; // reset
		while (((&htim11)->Instance->CNT) < (START_PAUSE_00 + T_PAUSE ))
		{

		}
		GPIOB->BSRR = GPIO_PIN_8; // set
		while (((&htim11)->Instance->CNT) > 200)
		{

		}

	}
	else if (bit1 == 0 && bit2 == 1)
	{
		// delay is 384/fc
		while (((&htim11)->Instance->CNT) < START_PAUSE_01)
		{

		}
		GPIOB->BSRR = (uint32_t)GPIO_PIN_8 << 16U; // reset
		while (((&htim11)->Instance->CNT) < (START_PAUSE_01 + T_PAUSE ))
		{

		}
		GPIOB->BSRR = GPIO_PIN_8; // set
		while (((&htim11)->Instance->CNT) > 200)
		{

		}

	}
	else if (bit1 == 1 && bit2 == 0)
	{
		//delay is 640/fc
		while (((&htim11)->Instance->CNT) < START_PAUSE_10)
		{

		}

		GPIOB->BSRR = (uint32_t)GPIO_PIN_8 << 16U; // reset
		while (((&htim11)->Instance->CNT) < (START_PAUSE_10 + T_PAUSE ))
		{

		}
		GPIOB->BSRR = GPIO_PIN_8; // set
		while (((&htim11)->Instance->CNT) > 200)
		{

		}

	}
	else
	{
		// delay is 896/fc
		while (((&htim11)->Instance->CNT) < START_PAUSE_11)
		{

		}
		GPIOB->BSRR = (uint32_t)GPIO_PIN_8 << 16U; // reset
		while (((&htim11)->Instance->CNT) > 200)
		{

		}
		GPIOB->BSRR = GPIO_PIN_8; // set

	}

}


void EOF1(void) // 256/fc -> pause -> 128/fc
{
	// delay is 896/fc
	while (__HAL_TIM_GET_COUNTER(&htim11) < START_PAUSE_EOF)
	{

	}
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
	while (__HAL_TIM_GET_COUNTER(&htim11) < (START_PAUSE_EOF + T_PAUSE ))
	{

	}

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET); HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
	while (__HAL_TIM_GET_COUNTER(&htim11) < 3172)
	{

	}
	HAL_TIM_Base_Stop(&htim11); // start timer
	__HAL_TIM_SET_COUNTER(&htim11,0);
}


void SOF(void) // pause -> 512/fc -> pause -> 256/fc
{
	// delay is 896/fc
	HAL_TIM_Base_Start(&htim11); // start timer
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
	while (__HAL_TIM_GET_COUNTER(&htim11) < (T_PAUSE ))
		{
		}
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
	while (__HAL_TIM_GET_COUNTER(&htim11) < (3172+T_PAUSE))
		{
		}
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
	while (__HAL_TIM_GET_COUNTER(&htim11) < (T_PAUSE +3172+T_PAUSE))
		{
		}
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
	while (__HAL_TIM_GET_COUNTER(&htim11) > (200))
			{
			}

}


void generate_binary_message(int message1[], int *message_b) // LSB first
{
    unsigned int CRC_c = 0x00;
    CRC_c = calc_crc(message1, NUMBER_OF_BYTES); // calculate CRC
    message1[NUMBER_OF_BYTES] = (CRC_c & 0XFF); // add CRC LSB
    message1[NUMBER_OF_BYTES+1] = (CRC_c >>8); // add CRC MSB
    int count,count2, i;
    count2 = 0;
    for (count = 0; count <= NUMBER_OF_BYTES+1; count++) // loop through bytes of message
    {
        int message_b_temp[8] = {0,0,0,0,0,0,0,0};
        i = 0;
        decToBinary(message1[count], message_b_temp);  // convert to binary LSB first
        while(count2 < count*8 +8) // loop through bits and append onto message
        {
            message_b[count2] = message_b_temp[i];
            i = i+1;
            count2 = count2+1;
        }
    }
}

void decToBinary(int n, int *binaryNum) // using pointer to change binaryNum
{
    int i = 0;
    while (n > 0) {
        binaryNum[i] = n % 2; // storing remainder in binary array
        n = n / 2;
        i++;
    }
}


int calc_crc(int *array_of_databytes, int number_of_databytes) // outputs MSB first but we always want to transmit LSB first
{
    unsigned int current_crc_value = 0xFFFF;
	int i, j;

	for (i = 0; i < number_of_databytes; i++)
	{
		current_crc_value = current_crc_value ^ ((unsigned int)array_of_databytes[i]);
		for (j = 0; j < 8; j++)
		{
			if (current_crc_value & 0x0001)
			{
				current_crc_value = (current_crc_value >> 1) ^ POLYNOMIAL;
			}
			else
			{
				current_crc_value = (current_crc_value >> 1);
			}
		}
	}
    current_crc_value = ~current_crc_value;
    return current_crc_value & 0xFFFF;
}






/////////////////////////////////////////////// TEST ///////////////////////////////////////////////

/*
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	//HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
	//HAL_Delay(3);
	//HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
	//test1 = 1;

	//char msg[10];
	//for(int i=0; i < BUFF_LENGTH; i++){
    //sprintf(msg,"%hu, ", adc_buff[i]);
	//HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	//}
	HAL_ADC_Stop_DMA(&hadc1);
	char msg[20];
    for(int i=0; i < 100; i++){ // to flush out
            sprintf(msg,"%hu, B ",1);
            HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
        }
    for(int i=0; i < 42768; i++){
        sprintf(msg,"%hu, ", buff[i]);
        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
    }
    sprintf(msg,"//////////////////////////// "); // to see end point
    HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);

    HAL_Delay(20000);

}
*/


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
