/*
 * receive_difference.c
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#define BUFF_LENGTH 32768
#define MAX_MESSAGE_LENGTH 96 +3 // sof ends with 1, eof starts with 0// then eof // goes over buff_length if 512
#define WINDOW_LENGTH_bits  247.594 // exactly 151.04 us // depending on how getting SOF these values may need to change
#define WINDOW_LENGTH_bits_DIV 124//123.8
#define LOOP_INCREMENT 40
ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;

void receive_difference(uint8_t *message)
{
	uint16_t adc_buff[BUFF_LENGTH];

	//define test variables
	int test1=0,test2=0;
	int message_true[] = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,1,0,1,1,0,3};
	char msg[10];

    //define variables for receiver
	int message_location =0,window_temp, i,k, max_val, min_val;
	float window_location = 0.0;
	uint32_t c_1, c_0;

    //define variables for filtering
    float a[4] = {1,-2.6862, 2.4197, -0.7302};
	int past[3] = {0,0,0};

	// define variables for EOF
    int filtered=0, found =0, past_1=0, past_2=0, threshold;

	// wait for SOF
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
    while (__HAL_TIM_GET_COUNTER(&htim7) < 62100) //62100  10043
    {

    }
    HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7,0);

	// start DMA
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buff,BUFF_LENGTH); // this command takes 43.3 us
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);

    while (message_location <MAX_MESSAGE_LENGTH && found ==0)
    {
    	//reset
    	HAL_TIM_Base_Start(&htim7);
    	c_1=0;c_0=0;
    	window_temp = window_location;
        uint16_t *buff_P = &adc_buff[window_temp];

		for (k = 0; k < WINDOW_LENGTH_bits_DIV; k+=LOOP_INCREMENT)
		{
			max_val = 0;min_val = 10000000;
			for (i = 0; (i < LOOP_INCREMENT && (i+k) < WINDOW_LENGTH_bits_DIV); i++)
			{
				filtered = buff_P[k+i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
				past[2] = past[1];
				past[1] = past[0];
				past[0] = filtered;

				if (filtered > max_val)
				{
					max_val = filtered;
				}
				if (filtered < min_val)
				{
					min_val = filtered;
				}
			}
			c_0 += max_val - min_val;
		}
		for (k = WINDOW_LENGTH_bits_DIV; k < (WINDOW_LENGTH_bits+10); k+=LOOP_INCREMENT)
		{
			max_val = 0; min_val = 10000000;
			for (i = 0; (i < LOOP_INCREMENT && (i+k) < WINDOW_LENGTH_bits); i++)
			{
				filtered = buff_P[k+i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
				past[2] = past[1];
				past[1] = past[0];
				past[0] = filtered;
				if (filtered > max_val)
				{
					max_val = filtered;
				}
				if (filtered < min_val)
				{
					min_val = filtered;
				}
			}
			c_1 += max_val - min_val;
		}

		if(c_1 > c_0)
		{
			threshold = 0;//(past_2 - c_1)/c_1; // (c_0+c_1)*c_0
			if(threshold > 0.018 && message[message_location-1] == 0 && message_location>24)
			{
				message[message_location] = 3;
				found =1;
			}
			else
			{
				message[message_location] = 1;
			}
			past_2 = past_1;
			past_1 = c_1;
		}
		else
		{
			threshold = 0;//(past_2 - c_0)/c_0; // (c_0+c_1)*c_0
			if(threshold > 0.018 && message[message_location-1] == 0 && message_location>24)
			{
				message[message_location] = 3;
				found =1;
			}
			else
			{
				message[message_location] = 0;
			}
			past_2 = past_1;
			past_1 = c_0;
		}

		// IN WHILE

		//update locations
        message_location +=1; window_location += WINDOW_LENGTH_bits;

        //make sure we dont go too quickly
        while(__HAL_TIM_GET_COUNTER(&htim7) < 15000) // 12688 if being exact
        {

        }
        HAL_TIM_Base_Stop(&htim7);
       __HAL_TIM_SET_COUNTER(&htim7,0);

    }
    // OUT WHILE


    // stop ADC
    HAL_ADC_Stop_DMA(&hadc1);

    // DISPLAY TO USER

    // display errors
    int errors =0;
    for(int i=0; i < 98; i++)
	{
    		if(message[i] != message_true[i])
    		{
    			errors+=1;
    		}

	}
//    sprintf(msg," %d,  ", errors); // to see end point
//	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);

//	// display ADC data
//    if (errors <10 && errors < 30)
//    {
//
//        for(int i=0; i < 100; i++){ // to flush out
//                sprintf(msg,"B, ");
//                HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
//            }
//        for(int i=4; i < window_location+800; i++){
////			filtered = adc_buff[i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
////			past[2] = past[1];
////			past[1] = past[0];
////			past[0] = filtered;
//			sprintf(msg,"%hu, ", adc_buff[i]);
//            HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
//        }
//        sprintf(msg,"///////%d///////////  ", errors);
//        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
//
//        HAL_Delay(30000);
//
//    }
//
////     // check CRC and display UID
//	int error1 = check_crc(message);
//	disp_uid(message, error1, errors);



}



