// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#define BUFF_LENGTH 32768
#define MAX_MESSAGE_LENGTH 96 +3 // sof ends with 1, eof starts with 0// then eof // goes over buff_length if 512
#define WINDOW_LENGTH_bits  247.7876 // exactly 151.04 us // depending on how getting SOF these values may need to change
#define WINDOW_LENGTH_bits_DIV 124//123.8
#define LOOP_INCREMENT 20
ADC_HandleTypeDef hadc2;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;

void receive(uint8_t *message, int avg_low) //, uint16_t *buffer)
{
	uint16_t adc_buff[BUFF_LENGTH];
	//define test variable
	int message_true[] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0,
			1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
			1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 3 };
	int test =0;
	//define variables for receiving bits
	int message_location = 0, window_temp, max_val;
	float window_location = 0.0;
	char msg[10];
	uint32_t c_1, c_0, small_p = avg_low;

	// define loop variables
	int i, k;

	//define variables for EOF
	int found = 0, past_1 = 0, past_2 = 0, threshold;

	// for till SOF
	while (__HAL_TIM_GET_COUNTER(&htim7) < 62100) //62100  10043 15993
	{

	}
	HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7, 0);

	// start DMA
	HAL_ADC_Start_DMA(&hadc2, (uint32_t*) adc_buff, BUFF_LENGTH); // this command takes 43.3 us

	while (message_location < 110 && found == 0)
	{
		HAL_TIM_Base_Start(&htim7);
		c_1 = 0;c_0 = 0;
		window_temp = window_location;
		uint16_t *buff_P = &adc_buff[window_temp];

		for (k = 0; k < WINDOW_LENGTH_bits_DIV; k += LOOP_INCREMENT) //TRY GET SO LAST ONE GOES TO WINDOW_LENGTH_bits_DIV
				{

			max_val = 0;
			for (i = 0; (i < LOOP_INCREMENT && (i+k) < WINDOW_LENGTH_bits_DIV); i++)
			{
				if (buff_P[k + i] > max_val)
				{
					max_val = buff_P[k + i];
				}
			}
			c_0 += max_val;
		}
		for (k = WINDOW_LENGTH_bits_DIV; k < (WINDOW_LENGTH_bits+10); k +=LOOP_INCREMENT)
		{
			max_val = 0;
			for (i = 0; (i < LOOP_INCREMENT && (i+k) < WINDOW_LENGTH_bits); i++)
			{
				if (buff_P[k + i] > max_val)
				{
					max_val = buff_P[k + i];
				}
			}
			c_1 += max_val;
		}

		if (c_1 > c_0) {
			// signal is a 1
			threshold = (past_2 - c_1) ;
			if (threshold > 3 && message[message_location-1] == 0  && message_location > 24)
			{
				message[message_location] = 3;
				found = 1;
//				sprintf(msg,"%d,  ", message_location); // to see end point
//									HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
			} else
			{
				message[message_location] = 0;
			}
			past_2 = past_1;
			past_1 = c_0;

		} else
		{
			threshold = (past_2 - c_0);
			if (threshold > 3 && message[message_location-1] == 0 && message_location > 24)
			{
				message[message_location] = 3;
				found = 1;
//				sprintf(msg,"%d,  ", message_location); // to see end point
//									HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
			} else
			{
				message[message_location] = 1;
			}
			past_2 = past_1;
			past_1 = c_1;
		}
		// IN WHILE

		// update locations
		message_location += 1; window_location += WINDOW_LENGTH_bits;

		//make sure we dont go too quickly
		while (__HAL_TIM_GET_COUNTER(&htim7) < 15000) // 12688 if being exact
		{

		}
		HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7, 0);

	}

	// OUT WHILE

	// stop ADC
	HAL_ADC_Stop_DMA(&hadc2);

	// DISPLAY TO USER

	// find and display number of errors
	int errors = 0;
	int loc = 0;
	for (int i = 0; i < 98; i++) {
		if (message[i] != message_true[i]) {
			errors += 1;
			loc = i;
		}

	}
	sprintf(msg, "%d,  ", errors); // to see end point
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);


	// display ADC data
	if (errors >900 && errors < 400) {
		for (int i = 0; i < 100; i++) { // to flush out
			sprintf(msg, "%hu, B ", 1);
			HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),HAL_MAX_DELAY);
		}
		for (int i = 0; i < window_location + 800; i++) {
			sprintf(msg, "%hu, ", adc_buff[i]);
			HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),
					HAL_MAX_DELAY);
		}
		sprintf(msg, "//////////%d/////////////// ", errors); // to see end point
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);

		HAL_Delay(30000);
	}



	// check CRC and display UID
	int error1 = check_crc(message);
	disp_uid(message, error1, errors);

}
