/*
 * check_crc_disp_uid.c
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#define BUFF_LENGTH 32768
#define MAX_MESSAGE_LENGTH 96 +3 // sof ends with 1, eof starts with 0// then eof // goes over buff_length if 512
#define WINDOW_LENGTH_bits  247.2//247.594 // exactly 151.04 us // depending on how getting SOF these values may need to change
#define WINDOW_LENGTH_bits_DIV 124//123.8
#define LOOP_INCREMENT 20
ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;


int check_crc(uint8_t *message)
{
    int k;
    int errors = 0;
    int mess_hex[10]; // (message_location - 4)/8
    for (int i =0; i<10; i++)
    {
    	uint8_t *Px = &message[i*8+1];
        mess_hex[i] = binToHex(Px, 8);
    }
    unsigned int CRC_check = calc_crc(mess_hex, 10);
    int temp1[2];
	temp1[0] = (CRC_check & 0XFF); //MSB
	temp1[1] = (CRC_check >>8); // LSB
    int z;
    for (int i = 0; i<2; i++)
    {
        int message_b_temp[8] = {0,0,0,0,0,0,0,0};
        decToBinary(temp1[i], message_b_temp);  // convert to binary LSB first
		for(k = 0; k<8; k++)
		{
			if(i ==1)
            {
				z = 8;
			}
			else
			{
				z = 0;
			}
			if (message_b_temp[k] != message[81+k+z])
			{
				errors+=1;
			}
		}
    }
    return errors;


}
void disp_uid(uint8_t *message, int error1, int errors)
{
	char mess[20];
	if(error1 == 0)
		{
		    for(int k = 17; k<80; k+=8)
		    {
		        uint8_t *Px = &message[k];
		        int hexadecimalval = binToHex(Px, 8);
				sprintf(mess,"%02X", hexadecimalval);
				HAL_UART_Transmit(&huart2, (uint8_t*)mess,strlen(mess), HAL_MAX_DELAY);

		    }
		}
		else
		{
			if(errors <10)
			{
				sprintf(mess," ERRORS");
					HAL_UART_Transmit(&huart2, (uint8_t*)mess,strlen(mess), HAL_MAX_DELAY);
			}
			else
			{
				sprintf(mess,"NO CARD");
								HAL_UART_Transmit(&huart2, (uint8_t*)mess,strlen(mess), HAL_MAX_DELAY);
			}

		}

	sprintf(mess,"\r\n");
	HAL_UART_Transmit(&huart2, (uint8_t*)mess,strlen(mess), HAL_MAX_DELAY);
}
int binToHex(uint8_t *binaryval, int size)
{
    int remainder = 0;
    int hexadecimalval = 0;
    int i = 1, j=0;;
   while (j < size)
   {
      hexadecimalval = hexadecimalval + binaryval[j] * i;
      i = i * 2;
      j +=1;
   }
   return hexadecimalval;
}
