/*
 * determine_levels.c
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_adc1;

///////////////////////////////////////////////////////
/////////          CIRCULAR DMA
//////////////////////////////////////////////////////


int determine_levels_df(void)
{
	//define variables for filtering
	    float a[4] = {1,-2.6862, 2.4197, -0.7302};
		int past[4] = {0,0,0,0};

    uint64_t cum_sum = 0;
    int count;
    int threshold;
    HAL_TIM_Base_Start(&htim7);
	uint16_t sof_buff[256]; // use same adc just different buffer
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)sof_buff,256); // this command takes 43.3 us
    int  k = 0;
    while (__HAL_TIM_GET_COUNTER(&htim7) < 5500) //54970// 45848, 60270
    {

    }
    // GET UNMODULATED AVERAGE
    while (__HAL_TIM_GET_COUNTER(&htim7) < 44940) //54970// 45848, 60270)
	{
    	count = sof_buff[256 - ((&hdma_adc1)->Instance->NDTR) - 1] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
    					past[2] = past[1];
    					past[1] = past[0];
    					past[0] = count;
    	//if(k < 300)
    	//{
			cum_sum += count;
			k = k+1;
    	//}
    }

    int avg_low = cum_sum/k;

    HAL_TIM_Base_Stop(&htim7);
	__HAL_TIM_SET_COUNTER(&htim7,0);
	HAL_TIM_Base_Start(&htim7);
	cum_sum = 0;k=0;

	while (__HAL_TIM_GET_COUNTER(&htim7) < 2000) //54970// 45848, 60270
	    {

	    }
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
	// CHECK FOR MODULATION
    while (__HAL_TIM_GET_COUNTER(&htim7) < 19060 ) // only need to search in very specific range where first peak could occur
    {
    	count = sof_buff[256 - ((&hdma_adc1)->Instance->NDTR) - 1] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
    	    					past[2] = past[1];
    	    					past[1] = past[0];
    	    					past[0] = count;
			//if(k < 300)
        	//{
    			cum_sum += count;
    			k = k+1;
        	//}
    }

    int avg_high = cum_sum/k;
    threshold = (avg_low+avg_high)*0.5;
    HAL_ADC_Stop_DMA(&hadc1);
    HAL_TIM_Base_Stop(&htim7);
	__HAL_TIM_SET_COUNTER(&htim7,0);
	HAL_TIM_Base_Start(&htim7);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
	// display thresholds
	/*
	char msg[15];
	sprintf(msg,"THRESH: %d,  ", threshold); // to see end point
	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	sprintf(msg,"HIGH: %d,  ", avg_high); // to see end point
	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	sprintf(msg,"LOW: %d,  ", avg_low); // to see end point
	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
*/

    return threshold;

/*//test wait time
    while (__HAL_TIM_GET_COUNTER(&htim7) < 15993) //54970// 45848, 60270
    {

    }
    HAL_TIM_Base_Stop(&htim7);
	__HAL_TIM_SET_COUNTER(&htim7,0);
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buff,BUFF_LENGTH); // this command takes 43.3 us

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
	HAL_ADC_Stop_DMA(&hadc1);
	//char msg[10];
	//sprintf(msg,"%d, ", adc_val);
	//HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	 */
}
