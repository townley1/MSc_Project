// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_adc1;


void toa(void)
{

	// define variables for unmodulated average
	int i, temp1,temp2;
	float a[4] = {1,-2.6862, 2.4197, -0.7302};
    uint32_t avg_1=0, avg_2=0;
    int thresh1, thresh2, found1=0,found2=0, current1,current2;
    char msg[20];
    int past[4] = {0,0,0,0};
    int past2[4] = {0,0,0,0};
    // start DMA
    uint16_t sof_buff1[8192], sof_buff2[8192];
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)sof_buff1,8192); // this command takes 43.3 us
    HAL_ADC_Start_DMA(&hadc2, (uint32_t*)sof_buff2,8192); // this command takes 43.3 us

    HAL_Delay(100);
    HAL_ADC_Stop_DMA(&hadc1);
    	HAL_ADC_Stop_DMA(&hadc2);
    HAL_Delay(100);

    for (i = 0; i<30; i++)
    {
    	temp1 = sof_buff1[i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
    			past[2] = past[1];
    			past[1] = past[0];
    			past[0] = temp1;

    			temp2 = sof_buff2[i] - past2[0]*a[1] -past2[1]*a[2] - past2[2]*a[3];
    			past2[2] = past2[1];
    			past2[1] = past2[0];
    			past2[0] = temp2;
    }
    for(i =30;i<210;i++)
    {
		temp1 = sof_buff1[i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
		past[2] = past[1];
		past[1] = past[0];
		past[0] = temp1;

		temp2 = sof_buff2[i] - past2[0]*a[1] -past2[1]*a[2] - past2[2]*a[3];
		past2[2] = past2[1];
		past2[1] = past2[0];
		past2[0] = temp2;

		avg_1 += temp1;
		avg_2 += temp2;

    }
    thresh1 = (avg_1/180)*1.7;
    thresh2 = (avg_2/180)/1.1;
    while(i< 8180 && (found1 ==0 || found2 == 0))
    {
    	current1 = sof_buff1[i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
    					past[2] = past[1];
    					past[1] = past[0];
    					past[0] = current1;

		current2 = sof_buff2[i] - past2[0]*a[1] -past2[1]*a[2] - past2[2]*a[3];
						past2[2] = past2[1];
						past2[1] = past2[0];
						past2[0] = current2;
    	if(current1 > thresh1 && found1 ==0 && i>230)
    	{
    		found1 = i;
    	}
    	if (current2 < thresh2 && found2 == 0 && i > 230)
    	{
    		found2 = i ;
    	}
    	i +=1;
    }
    int diff = found1- found2;
    sprintf(msg, "found1: %hu,  ", found1);
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),HAL_MAX_DELAY);
	sprintf(msg, "found2: %hu,  ", found2);
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),HAL_MAX_DELAY);
	sprintf(msg, "diff: %hu,  ", diff);
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),HAL_MAX_DELAY);
	sprintf(msg, "thresh1: %hu,  ", thresh1);
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),HAL_MAX_DELAY);
	sprintf(msg, "thresh2: %hu,  ", thresh2);
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),HAL_MAX_DELAY);
	sprintf(msg, " \n\r  ");
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg),HAL_MAX_DELAY);

	if(diff ==46 || diff < -49)
	{
	    for( i=0; i < 8180; i++){
			sprintf(msg,"%hu, ", sof_buff1[i]);
	        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	    }
	    sprintf(msg,"\n\r"); // to see end point
	        			HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	    for( i=0; i < 8180; i++){

			sprintf(msg,"%hu, ", sof_buff2[i]);
	        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	    }
	    sprintf(msg,"\n\r"); // to see end point
	    			HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	    			sprintf(msg,"\n\r"); // to see end point
	    			    			HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
	    HAL_Delay(30000);


	}
}

