/*
 * receiving_functions.h
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

#ifndef SRC_RECEIVING_FUNCTIONS_H_
#define SRC_RECEIVING_FUNCTIONS_H_


// define values for RECEIVER
int binToHex(uint8_t *binaryval, int size);
void disp_uid(uint8_t *message, int, int);
int check_crc(uint8_t *message);
void receive(uint8_t *, int);
int find_SOF(void);
void start_dma(ADC_HandleTypeDef *, uint32_t *, uint32_t );
int determine_levels(void) ;
int determine_levels_df(void) ;
void receive_difference(uint8_t *);
void receive_correlation_filtered(uint8_t *);
void receive_threshold_df(uint8_t *, int );
void receive_filtered(uint8_t *, int);
void receive_threshold(uint8_t *, int );
void toa(void);
void receive_derivative(uint8_t *, int);
int findAvg(void);



#endif /* SRC_RECEIVING_FUNCTIONS_H_ */
