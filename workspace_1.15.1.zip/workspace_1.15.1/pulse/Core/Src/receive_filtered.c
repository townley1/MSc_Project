/*
 * receive_filtered.c
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#define BUFF_LENGTH 32768
#define MAX_MESSAGE_LENGTH 96 +3 // sof ends with 1, eof starts with 0// then eof // goes over buff_length if 512
#define WINDOW_LENGTH_bits  247.594 // exactly 151.04 us // depending on how getting SOF these values may need to change
#define WINDOW_LENGTH_bits_DIV 124//123.8
#define LOOP_INCREMENT 20
ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_adc1;


void receive_filtered(uint8_t *message, int avg_low)//, uint16_t *buffer)
{
	uint16_t adc_buff[BUFF_LENGTH];

	//define test variables
	int message_true[] = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,1,0,1,1,0,3};
	char msg[10];
	int test=0;

	//define receiving variables
	int message_location =0,window_temp,i, k, max_val, c_1, c_0;
    float window_location = 0.0;


    //define variables for filtering
    float a[4] = {1,-2.6862, 2.4197, -0.7302};
	int past[4] = {0,0,0,0}; int filtered;

	//define EOF variables
	int past_1=0,past_2=0, threshold =0;
	int found =0;

	//wait for SOF
    while (__HAL_TIM_GET_COUNTER(&htim7) < 62100) //62100  10043 15993
    {

    }
    HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7,0);

    // start ADC
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buff,BUFF_LENGTH); // this command takes 43.3 us


    while (message_location <110 && found ==0)
    {
    	//Reset
    	HAL_TIM_Base_Start(&htim7);
    	c_1=0;c_0=0;
    	window_temp = window_location;
        uint16_t *buff_P = &adc_buff[window_temp];

		for (k = 0; k < WINDOW_LENGTH_bits_DIV; k+=LOOP_INCREMENT)
		{
			max_val = 0;
			for (i = 0; (i < LOOP_INCREMENT && (i+k) < WINDOW_LENGTH_bits_DIV); i++)
			{
				filtered = buff_P[k+i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
				past[2] = past[1];
				past[1] = past[0];
				past[0] = filtered;

				if (filtered > max_val)
				{
					max_val = filtered;
				}
			}
			c_0 += max_val;
		}
		for (k = WINDOW_LENGTH_bits_DIV; k < (WINDOW_LENGTH_bits+10); k+=LOOP_INCREMENT)
		{
			max_val = 0;
			for (i = 0; (i < LOOP_INCREMENT && (i+k) < WINDOW_LENGTH_bits); i++)
			{
				filtered = buff_P[k+i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
				past[2] = past[1];
				past[1] = past[0];
				past[0] = filtered;
				if (filtered > max_val)
				{
					max_val = filtered;
				}
			}
			c_1 += max_val;
		}

		if(c_1 > c_0)
		{
			threshold = (past_2 - c_1);//c_1;

			if(threshold > 1000 && message[message_location-1] == 0 && message_location>24)
			{
				message[message_location] = 3;
				found =1;
				sprintf(msg,"%d,  ", message_location); // to see end point
					HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
			}
			else
			{
				message[message_location] = 0;
			}
			past_2 = past_1;
			past_1 = c_0;
		}
		else
		{
			threshold = (past_2 - c_0);//c_0;
			if(threshold > 1000 && message[message_location-1] == 0 && message_location>24)
			{
				message[message_location] = 3;
				found =1;
				sprintf(msg,"%d,  ", message_location); // to see end point
					HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
			}
			else
			{
				message[message_location] = 1;
			}
			past_2 = past_1;
			past_1 = c_1;
		}

		// IN WHILE

		//update location variables
        message_location +=1;
        window_location += WINDOW_LENGTH_bits;

        //make sure we dont go too quickly
        while(__HAL_TIM_GET_COUNTER(&htim7) < 15000) // 12688 if being exact
        {

        }
        HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7,0);

    }

    // OUT WHILE


    // stop ADC
    HAL_ADC_Stop_DMA(&hadc1);


 // DISPLAY TO USER


    // display errors
    int errors =0;
    for(int i=0; i < 98; i++)
	{
    		if(message[i] != message_true[i])
    		{
    			errors+=1;
    		}

	}
    sprintf(msg,"%d,  ", errors); // to see end point
	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);


	// display ADC data
    if (errors >1000 && errors <500 )
    {

        for(int i=0; i < 100; i++){ // to flush out
                sprintf(msg,"%hu, B ",1);
                HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
            }
        for(int i=0; i < window_location+800; i++){
            sprintf(msg,"%hu, ", adc_buff[i]);
            HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
        }
        sprintf(msg,"//////////%d////////// ", errors); // to see end point
        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);

        HAL_Delay(30000);

    }

     // check CRC and display UID
	int error1 = check_crc(message);
	disp_uid(message, error1, errors);



}
