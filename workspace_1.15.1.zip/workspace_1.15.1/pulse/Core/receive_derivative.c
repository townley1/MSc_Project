/*
 * receive_difference.c
 *
 *  Created on: Jul 6, 2024
 *      Author: Benet
 */

// libraries
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#define BUFF_LENGTH 32768
int abs(int x);
#define MAX_MESSAGE_LENGTH 96 +3 // sof ends with 1, eof starts with 0// then eof // goes over buff_length if 512
#define WINDOW_LENGTH_bits  248 // exactly 151.04 us // depending on how getting SOF these values may need to change
#define WINDOW_LENGTH_bits_DIV 124//123.8
#define LOOP_INCREMENT 40
ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim7;
UART_HandleTypeDef huart2;

void receive_derivative(uint8_t *message,int threshold)
{
	uint16_t adc_buff[BUFF_LENGTH];

	//define test variables
	int message_true[] = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,0,0,1,0,1,0,1,1,0,3};
	char msg[10];

    //define variables for receiver
	int message_location =0,window_temp,k;
	float window_location = 0.0;
	uint32_t c_1, c_0;

    //define variables for filtering
    float a[6] = {1.0000,   -4.4918 ,   8.0941 ,  -7.3121 ,   3.3110,   -0.6011};
//	float a[4] = {1,-2.6862, 2.4197, -0.7302};
	int past[5] = {0,0,0,0,0};
	int counter = 0;
	// define variables for EOF
    int filtered=0, found =0, prev2;
    int difference=0, difference_past = 0, prev1;
	// wait for SOF
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
    while (__HAL_TIM_GET_COUNTER(&htim7) < 62100) //62100  10043
    {

    }
    HAL_TIM_Base_Stop(&htim7); __HAL_TIM_SET_COUNTER(&htim7,0);

	// start DMA
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buff,BUFF_LENGTH); // this command takes 43.3 us
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);

    while (message_location <MAX_MESSAGE_LENGTH )
    {
    	//reset
    	HAL_TIM_Base_Start(&htim7);
    	window_temp = window_location;
        uint16_t *buff_P = &adc_buff[window_temp];
        prev1 = threshold; prev2 = threshold;
        c_1=0;c_0=0;counter=0;

		for (k = 0; k < WINDOW_LENGTH_bits_DIV; k++)
		{

			filtered = buff_P[k] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3] - past[3]*a[4] - past[4]*a[5];
							past[4] = past[3];
							past[3] = past[2];
							past[2] = past[1];
							past[1] = past[0];
							past[0] = filtered;
//			filtered = buff_P[k] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
//							past[2] = past[1];
//							past[1] = past[0];
//							past[0] = filtered;

			difference = filtered - past[1];
			if ((difference >0 && difference_past <0)  || (difference <0 && difference_past >0))
			{
				if(found ==0)
				{
					prev1 = filtered;
					found = 1;
				}
				else
				{
					c_0 += abs(filtered - prev1);counter+=1;prev1 = filtered;
				}

			}

			difference_past = difference;


		}
		c_0 = c_0/counter;
		counter = 0;

		for (k = (WINDOW_LENGTH_bits_DIV); k < (WINDOW_LENGTH_bits); k++)
		{
				filtered = buff_P[k] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3] - past[3]*a[4] - past[4]*a[5];
				past[4] = past[3];
				past[3] = past[2];
				past[2] = past[1];
				past[1] = past[0];
				past[0] = filtered;
//			filtered = buff_P[k] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
//							past[2] = past[1];
//							past[1] = past[0];
//							past[0] = filtered;

				difference = filtered - past[1];

				if ((difference >0 && difference_past <0)  || (difference <0 && difference_past >0))
				{
					if(found ==0)
					{
						prev1 = filtered;
						found = 1;
					}
					else
					{
					c_1 += abs(filtered - prev2);counter+=1;prev2 = filtered;
					}
				}
				difference_past = difference;

		}
		c_1 = c_1/counter;
		if(c_1 > c_0)
		{
			message[message_location] = 1;
		}
		else
		{
			message[message_location] = 0;
		}


		// IN WHILE

		//update locations
        message_location +=1; window_location += WINDOW_LENGTH_bits;

        //make sure we dont go too quickly
        while(__HAL_TIM_GET_COUNTER(&htim7) < 15000) // 12688 if being exact
        {

        }
        HAL_TIM_Base_Stop(&htim7);
       __HAL_TIM_SET_COUNTER(&htim7,0);

    }
    // OUT WHILE


    // stop ADC
    HAL_ADC_Stop_DMA(&hadc1);

    // DISPLAY TO USER

    // display errors
    int errors =0;
    for(int i=0; i < 98; i++)
	{
    		if(message[i] != message_true[i])
    		{
    			errors+=1;
    		}

	}
    sprintf(msg," %d,  ", errors); // to see end point
	HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);

	// display ADC data
    if (errors >300 && errors < 10)
    {

        for(int i=0; i < 100; i++){ // to flush out
                sprintf(msg,"B, ");
                HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
            }
        for(int i=4; i < window_location+800; i++){
//			filtered = adc_buff[i] - past[0]*a[1] -past[1]*a[2] - past[2]*a[3];
//			past[2] = past[1];
//			past[1] = past[0];
//			past[0] = filtered;
			sprintf(msg,"%hu, ", adc_buff[i]);
            HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);
        }
        sprintf(msg,"///////%d///////////  ", errors);
        HAL_UART_Transmit(&huart2, (uint8_t*)msg,strlen(msg), HAL_MAX_DELAY);

        HAL_Delay(30000);

    }

//     // check CRC and display UID
	int error1 = check_crc(message);
	disp_uid(message, error1, errors);



}



